- 关注公众号：“祁大聪” 获取

获取，课程表小程序：

1、小程如何运行

2、微信小程序如何迁移到QQ小程序

3、如何成功发布上线

## 效果预览

- 参考 r1.jpg

![20220630165052](https://cdn.jsdelivr.net/gh/qicongmark/blob-img@master/20220630165052.4ogewyzdpls0.webp)